package Clases;

public class DeportistaEnDisciplina {
private int idDeportista, idDisciplina;
	
	public DeportistaEnDisciplina(int idDeportista, int idDisciplina) {
		this.idDeportista = idDeportista;
		this.idDisciplina = idDisciplina;
	}

	public DeportistaEnDisciplina() {
		// TODO Auto-generated constructor stub
	}

	public int getIdDeportista() {
		return idDeportista;
	}

	public void setIdDeportista(int idDeportista) {
		this.idDeportista = idDeportista;
	}

	public int getIdDisciplina() {
		return idDisciplina;
	}

	public void setIdDisciplina(int idDisciplina) {
		this.idDisciplina = idDisciplina;
	}

}


